import java.util.ArrayList;
import java.util.List;

public class npc
{
    // instance variables - replace the example below with your own
    private String name;
    private int health;
    private int maxHealth;
    private int stamina;
    private int actionPoints;
    
    private int strength;
    private int wisdom;
    private int agility;
    
    private double accuracy;
    private double evasion;
    
    private double physicalResistance;
    private double magicalResistance;
    
    private ability[] abilities;
    
    private int score;
    private boolean defeated;

    public npc()
    {
        name = "Template";
        health = 100;
        stamina = 100;
        actionPoints = 6;
        
        strength = 1;
        wisdom = 1;
        agility = 1;
        
        accuracy = 35;
        evasion = 5;
        
        physicalResistance = 0.25;
        magicalResistance = 0.25;
        
        abilities = new ability[4];
        
        score = 0;
        defeated = false;
    }

    public npc(String Name)
    {
        // initialise instance variables
        name = Name;
        health = maxHealth;
        maxHealth = 100;
        stamina = 100;
        actionPoints = 6;
        
        strength = 1;
        wisdom = 1;
        agility = 1;
        
        accuracy = 0.35;
        evasion = 0.5;
        
        physicalResistance = 0.25;
        magicalResistance = 0.25;
        
        abilities = new ability[4];
        abilities[0] = new ability(0,0,0);
        abilities[1] = new ability(0,1,0);
        abilities[2] = new ability();
        abilities[3] = new ability();
        score = 0;
        defeated = false;
    }
    
    public void getInfo()
    {
        System.out.println("Name: " + this.name);
        System.out.println("Health: " + this.health);
        System.out.println("Stamina: " + this.stamina);
        System.out.println("Action Points: " + this.actionPoints);

        System.out.println("Strength: " + this.strength);
        System.out.println("Wisdom: " + this.wisdom);
        System.out.println("Agility: " + this.agility);

        System.out.println("Accuracy: " + (int) this.accuracy + "%");
        System.out.println("Evasion: " + (int) this.evasion + "%");

        System.out.println("Physical Resistance: " + this.physicalResistance);
        System.out.println("Magical Resistance: " + this.magicalResistance);

        System.out.println("Score: " + this.score);
        System.out.println("Defeated: " + this.defeated);
        
        getAbilities();
    }
    
    public String getName()
    {
        return name;
    }
    
    public int getHealth()
    {
        return health;
    }
    
    public void getAbilities()
    {
        for (int i = 0; i < abilities.length; i++)
        {
            System.out.println("Abiltie Slot " + (i + 1) + ":" + abilities[i].getName());
        }
    }
    
    public void createAbility(int rarity, int core, int element)
    {
        for (int i = 2; i <= 3; i++)
        {
            if (abilities[i].getName() == "Empty")
            {
                ability a = new ability(rarity, core, element);
                abilities[i] = a;
                break;
            }
        }
    }
    
    public void damaged(int damage)
    {
        health -= damage;
        if (health <= 0)
            defeated = true;
    }
    
    public int attack()
    {
        return strength * 25;
    }
    
    public boolean isDefeated()
    {
        return defeated;
    }
}
