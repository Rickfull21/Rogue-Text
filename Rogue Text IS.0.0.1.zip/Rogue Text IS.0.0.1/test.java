import java.util.Scanner;

/**
 * Write a description of class test here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class test
{
    public static void main(String[] args)
    {
        userChoice choice = new userChoice();
        
        System.out.println("Testing for object user");
        user player = new user("Adventurer");
        player.getInfo();
        player.getAbilities();
        
        System.out.println("\nTesting combat");
        game game = new game();
        game.startAdventure(player, choice);
    }
}