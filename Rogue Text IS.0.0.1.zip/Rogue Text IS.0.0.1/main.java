import java.util.Scanner;
public class main
{
    public static void main(String[] args)
    {
        userChoice choice = new userChoice();
        
        System.out.println("Name your Adventurer.");
        user player = new user(choice.getStringChoice());
        
        player.getInfo();
        
    }
}