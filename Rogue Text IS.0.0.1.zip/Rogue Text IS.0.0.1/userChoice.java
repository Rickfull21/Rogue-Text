import java.util.Scanner;
public class userChoice {
    private final Scanner scanner;

    public userChoice() {
        this.scanner = new Scanner(System.in);
    }

    public String getStringChoice() {
        return this.scanner.nextLine(); 
    }
    
    public int getIntChoice()
    {
        return this.scanner.nextInt();
    }

    public void closeScanner() {
        this.scanner.close();
    }
}
