This is to pass the time during class.
Do not take this repo seriously.
This is the In School Version as I have to manually add anything in here because the school does not allow github commitws.