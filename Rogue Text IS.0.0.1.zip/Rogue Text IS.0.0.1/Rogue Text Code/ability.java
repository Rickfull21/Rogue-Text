
/**
 * Write a description of class Abilities here.
 *
 * @OR3O
 * @0.0.1
 */
public class ability
{
    // instance variables - replace the example below with your own
    private String name;
    private int coreType;
    private int elementType;
    private int damage;
    private int damageModifier;
    private int effectModifer;
    
    public ability()
    {
        name = "Empty";
        coreType = 0;
        elementType = 0;
        damage = 0;
    }
    
    public ability(int rarity, int element, int type)
    {
        name = generateName(rarity, element, type);
        coreType = type;
        elementType = type;
        damage = 1;
    }
    
    public String generateName(int rarity, int element, int type)
    {
        String generatedName = "Flail";
        
        return generatedName;
    }
    
    public String getName()
    {
        return name;
    }
}