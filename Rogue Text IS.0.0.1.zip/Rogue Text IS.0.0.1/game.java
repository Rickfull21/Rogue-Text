public class game
{
    // instance variables - replace the example below with your own
    private int turn;
    
    public game()
    {
        
    }
    
    
    public void startAdventure(user player, userChoice choice)
    {
        user enemy = new user("Goblin");
        generateIntro(player);
        
        beginBattle(player, enemy);
    }
    
    public void generateIntro(user player)
    {
        System.out.println("You seek to climb the Obsidian Spire of Voldera. Each floor tests your strength, will, and fate." +
        "You climb to claim whatever waits at the top.");
    }
    
    public void beginBattle(user player, user enemy)
    {
        userChoice choice = new userChoice();
        int pickedChoice = -1;
        
        System.out.println("You encounter " + enemy.getName() + " they are hostile and want to engage in combat.");
        System.out.println("What will you do?\n1. Fight\n2. Run");
        pickedChoice = choice.getIntChoice();
        if (pickedChoice == 1)
            {   
                while (player.isDefeated() == false)
                {  
                    int enemyChoice = 0;
                    System.out.println(enemy.getName() + " awaits your move." + "\nHow will you attack?\n");
                    player.getAbilities();
                    
                    pickedChoice = choice.getIntChoice();
                    
                    enemy.damaged(player.attack(pickedChoice), player.getAbilityCore(pickedChoice));
                    
                    
                    if (enemy.isDefeated() == false)
                        {
                        System.out.println("\nYou used " + player.getAbility(pickedChoice) + ". " + enemy.getName() + " now has " + enemy.getHealth() + " health.\n");
                        }
                    enemyChoice = (int) (Math.random() * 4) + 1;
                    player.damaged(enemy.attack(enemyChoice), enemy.getAbilityCore(enemyChoice));
                    System.out.println("\n" + enemy.getName() + " used " + enemy.getAbility(pickedChoice) + ". You now have " + player.getHealth() + " health.\n");

                    
                    if (enemy.isDefeated() == true)
                        {
                            System.out.println("\nYou have defeated the enemy. Proceed to the next floor? \n1.Yes\n2.No");
                            pickedChoice = choice.getIntChoice();
                            
                            if (pickedChoice == 2)
                            {
                                System.out.println("\nYou decided to leave the tower behind.\n");
                                //showScore();
                                break;
                            } else
                                {
                                    beginBattle(player, enemy);
                                }
                        }
                }
            }
        
    }
    
    public void generateEnemy()
    {
                
    }
}