
/**
 * Write a description of class Abilities here.
 *
 * @OR3O
 * @0.0.1
 */
public class ability
{
    // instance variables - replace the example below with your own
    private String name;
    private int coreType;
    private int elementType;
    private int damage;
    private int damageModifier;
    private int effectModifier;
    
    // Rarity 0 – Basic
    private String[] r0Physical = { "Quick Strike", "Heavy Swing", "Straight Jab", "Guard Break" };
    private String[] r0Magic = { "Bolt Cast", "Spark Shot", "Glimmer Burst", "Hex Tap" };
    private String[] r0Hybrid = { "Pulse Kick", "Surge Slash", "Burst Lunge", "Wave Crush" };

    // Rarity 1 – Uncommon
    private String[] r1Physical = { "Rending Cut", "Crushing Blow", "Hooking Slam", "Piercing Thrust" };
    private String[] r1Magic = { "Arc Burst", "Veil Pierce", "Sigil Snap", "Ward Fracture" };
    private String[] r1Hybrid = { "Torrent Drive", "Gale Break", "Flare Sweep", "Rift Step" };

    // Rarity 2 – Rare
    private String[] r2Physical = { "Crescent Cleave", "Shatter Smash", "Vortex Grapple", "Sunder Crash" };
    private String[] r2Magic = { "Nova Spiral", "Seal Detonation", "Mirage Lance", "Abyss Pull" };
    private String[] r2Hybrid = { "Storm Barrage", "Echo Reaver", "Spiral Breaker", "Drift Splitter" };

    // Rarity 3 – Epic
    private String[] r3Physical = { "Reign Breaker", "Titan Press", "Execution Rend", "Ruin Piledriver" };
    private String[] r3Magic = { "Crown Detonation", "Mantle Rupture", "Beacon Cataclysm", "Omen Cascade" };
    private String[] r3Hybrid = { "Cataclysm Rush", "Howling Rupture", "Riftbreaker Combo", "Tempest Overrun" };

    // Rarity 4 – Fabled
    private String[] r4Physical = { "Finality Cleave", "Oblivion Rend", "Ruinbreaker Strike", "King’s End Crush" };
    private String[] r4Magic = { "Last Dawn Nova", "Endless Night Rift", "Collapse Crown", "Eclipse Verdict" };
    private String[] r4Hybrid = { "Annihilation Pulse", "Cataclysm Surge", "Extinction Tide", "Worldsplit Step" };

    
    public ability()
    {
        name = "Empty";
        coreType = -1;
        elementType = -1;
        damage = 0;
        damageModifier = 0;
        effectModifier = 0;
    }
    
    public ability(int rarity, int core, int element)
    {
        name = generateName(rarity, core, element);
        coreType = core;
        elementType = element;
        damage = 25 + (100 * rarity/4);
        damageModifier = rarity/10;        
        
        //Damage Calculation
        
    }
    
    public String generateName(int rarity, int core, int element)
    {
        //Physical
        if (core == 0)
            if (rarity == 4)
            {
                name = r4Physical[(int) Math.random() * (r4Physical.length + 1)];
            } else if (rarity == 3)
            {
                name = r3Physical[(int) Math.random() * (r3Physical.length + 1)];
            } else if (rarity == 2)
            {
                name = r2Physical[(int) Math.random() * (r2Physical.length + 1)];
            } else if (rarity == 1)
            {
                name = r1Physical[(int) Math.random() * (r1Physical.length + 1)];;
            } else 
            name = r0Physical[(int) Math.random() * (r0Physical.length + 1)];
            
        //Magical
        else if (core == 1)
            {
                if (rarity == 4)
            {
                name = r4Magic[(int) Math.random() * (r4Magic.length + 1)];
            } else if (rarity == 3)
            {
                name = r3Magic[(int) Math.random() * (r3Magic.length + 1)];
            } else if (rarity == 2)
            {
                name = r2Magic[(int) Math.random() * (r2Magic.length + 1)];
            } else if (rarity == 1)
            {
                name = r1Magic[(int) Math.random() * (r1Magic.length + 1)];
            } else 
            name = r0Magic[(int) Math.random() * (r0Magic.length + 1)];
            }
        //Hybrid
        else if (core == 2)
            {
                if (rarity == 4)
            {
                name = r4Hybrid[(int) Math.random() * (r4Hybrid.length + 1)];
            } else if (rarity == 3)
            {
                name = r3Hybrid[(int) Math.random() * (r3Hybrid.length + 1)];
            } else if (rarity == 2)
            {
                name = r2Hybrid[(int) Math.random() * (r2Hybrid.length + 1)];
            } else if (rarity == 1)
            {
                name = r1Hybrid[(int) Math.random() * (r1Hybrid.length + 1)];
            } else 
            name = r0Hybrid[(int) Math.random() * (r0Hybrid.length + 1)];
            }
        return name;
    }
    
    public String getName()
    {
        return name;
    }
    
    public int getCore()
    {
        return coreType;
    }
    
    public int getDamage()
    {
        return damage + (damage * damageModifier);
    }
}